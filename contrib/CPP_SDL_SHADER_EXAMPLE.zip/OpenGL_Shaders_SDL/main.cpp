#ifdef WIN32
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>

#ifndef GLEW_STATIC
#define GLEW_STATIC
#endif

#include <gl\glew.h>			// OpenGL Extension Wrangler "autoloader"
#include <gl\gl.h>			// Microsoft OpenGL headers (version 1.1 by themselves)
#else // iOS?
// Barrett, what headers do you need?
#endif

#include <SDL.h>
// No need to include this here, conflicts with GLEW, but Barrett might need it.
// #include <SDL_opengl.h>

// Keep our shaders in local strings to keep it simple, a GLcharARB is typedef'd as a char
const GLcharARB* simpleMvpVertShader = 
                           "in vec4 vPosition;"
                           "in vec4 vColor;"
                           "uniform vec4	ambientLightAmt;"
                           "uniform mat4	mvpMat;"
                           "varying vec4 vFragColor; "
                           "void main()"
                           "{  "
                           "   vFragColor.r = vColor.r * ambientLightAmt.r;"
                           "   vFragColor.g = vColor.g * ambientLightAmt.g;"
                           "   vFragColor.b = vColor.b * ambientLightAmt.b;"
                           "   vFragColor.a = vColor.a * ambientLightAmt.a;"
                           "   gl_Position = mvpMat * vPosition;"
                           "}";

const GLcharARB* simpleWhiteFragShader =
                           "varying vec4 vFragColor;"
                           "void main()"
                           "{	"
                           "   gl_FragColor = vFragColor;"
                           "}";

// Loading shader function
// Got rid of all kinds of error handling here, just the simplest thing we need to make it work
GLhandleARB loadShader(const GLcharARB* shaderSrc, unsigned int type)
{
   GLhandleARB handle = glCreateShaderObjectARB(type);

   glShaderSourceARB(
      handle, //The handle to our shader
      1, //The number of shaders, we could use this function to do more than one at a time, but lets keep it simple.
      &shaderSrc, //An array of const char * data, which represents the source code of the shaders
      NULL);

   glCompileShaderARB(handle);

   return handle;
}

enum BufferIDs {
   VERTEX, COLOR, INDEX, NUM_BUFERS
};

class BouncingTriangle
{
private: // member variables
   GLuint bufferObjects[NUM_BUFERS];
   GLuint vertexArrayBufferObject;
   GLhandleARB progID;
   GLint	ambiLightAmt_uniform;
   GLint mvpMat_uniform;
   bool done;
   
private: // helper methods
   void BuildVBO();
   void LoadShaders();

public:
   BouncingTriangle();
   ~BouncingTriangle();

   void onReadyOpenGL(int w, int h);
   void onDisplay();
   void onEvent(SDL_Event& event);
   bool isDone() {return done;}

   Uint8* keys;
};

BouncingTriangle::BouncingTriangle()
{
   done = false;
   vertexArrayBufferObject = 0;
   for (int i = 0; i < NUM_BUFERS; ++i)
      bufferObjects[i] = 0;
}

BouncingTriangle::~BouncingTriangle()
{
   glUseProgramObjectARB(0);
   glDeleteBuffers(NUM_BUFERS, bufferObjects);
   glBindVertexArray(0);
   glDeleteVertexArrays(1, &vertexArrayBufferObject);
}

// A single triangle in ND Clip-SPace coords.
const int NUM_VERTS = 3;
GLfloat TriangleVerts[] = {   -0.5f, 0.0f, 0.0f, 
   0.5f, 0.0f, 0.0f,
   0.0f, 0.5f, 0.0f };

GLfloat TriangleColors[] = {  1.0f, 0.0f, 0.0f, 
   0.0f, 1.0f, 0.0f,
   0.0f, 0.0f, 1.0f };

const int NUM_INDEX = 3;
GLushort Indexes[] = {0,1,2};

void BouncingTriangle::BuildVBO()
{
   // Create the VBO and bind to it
   glGenVertexArrays(1, &vertexArrayBufferObject);
   glBindVertexArray(vertexArrayBufferObject);

   // Now that we are bound to our VBO, we can generate buffer objects and add them to it
   glGenBuffers(NUM_BUFERS, bufferObjects);

   glBindBuffer(GL_ARRAY_BUFFER, bufferObjects[VERTEX]);
   glEnableVertexAttribArray(VERTEX);
   glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*NUM_VERTS*3, TriangleVerts, GL_STATIC_DRAW);
   glVertexAttribPointer(VERTEX, 3, GL_FLOAT, GL_FALSE, 0, 0);

   glBindBuffer(GL_ARRAY_BUFFER, bufferObjects[COLOR]);
   glEnableVertexAttribArray(COLOR);
   glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*NUM_VERTS*3, TriangleColors, GL_STATIC_DRAW);
   glVertexAttribPointer(COLOR, 3, GL_FLOAT, GL_FALSE, 0, 0);

   // Indexes
   glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bufferObjects[INDEX]);
   glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(GLushort)*NUM_INDEX, Indexes, GL_STATIC_DRAW);

   // Since we are done, we should unbind our VBO
   glBindVertexArray(0);
}

void BouncingTriangle::LoadShaders()
{
   GLhandleARB vertShader = loadShader(simpleMvpVertShader, GL_VERTEX_SHADER);
   GLhandleARB fragShader = loadShader(simpleWhiteFragShader, GL_FRAGMENT_SHADER);
   progID = glCreateProgramObjectARB();
   glAttachObjectARB(progID,vertShader);
   glAttachObjectARB(progID,fragShader);

   glBindAttribLocation(progID, VERTEX, "vPosition");
   glBindAttribLocation(progID, COLOR, "vColor");
   glLinkProgramARB(progID); // Must link AFTER binding attributes, but BEFORE getting uniform locations

   ambiLightAmt_uniform = glGetUniformLocation(progID, "ambientLightAmt");
   mvpMat_uniform = glGetUniformLocation(progID, "mvpMat");
}

void BouncingTriangle::onEvent(SDL_Event& event)
{
   if (keys[SDLK_ESCAPE] || event.type==SDL_QUIT) {
      done=true;
   }
   // Do more if you wish
}

void BouncingTriangle::onReadyOpenGL(int w, int h)
{
   // This call will grab openGL extension function pointers.
   // This is not necessary for macosx and linux
#ifdef _WIN32
   GLenum err = glewInit();
   if (GLEW_OK != err) {
      fprintf(stderr, "GLEW Error: %s\n", glewGetErrorString(err));
      return;
   }
#endif

   // Setup the viewport to fill the window
   glViewport(0, 0, (GLsizei)w, (GLsizei)h);

   // make the background black
   glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

   // Turn on depth testing
   glEnable(GL_DEPTH_TEST);

   // We have only one shader program to use
   LoadShaders();

   // Create the VBO for the triangle
   BuildVBO();
}

// And Finally, lets deal with the loop
void BouncingTriangle::onDisplay()
{
   // Clear the screen
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

   // Use our own shader program
   glUseProgramObjectARB(progID);

   // We are going to bounce back and forth the ambient color and the position
   static float PingPong = 0.0;
   static float ppInc = 0.01f;
   PingPong += ppInc;
   if (PingPong > 1.0f)
   {
      PingPong = 2.0f - PingPong;
      ppInc *= -1.0f;
   }
   else if (PingPong < 0.0f)
   {
      PingPong *= -1.0f;
      ppInc *= -1.0f;
   }

   // Set the ambient light amount
   GLfloat vAmbientLight[] = { 1.0f - PingPong, PingPong, PingPong, 1.0f };
   glUniform4fv(ambiLightAmt_uniform, 1, vAmbientLight);

   // How about a matrix?  Simply a transform in X
   GLfloat transMat[] = {  1.0f, 0.0f, 0.0f, 2.0f*PingPong - 1.0f,
      0.0f, 1.0f, 0.0f, 0.0f,
      0.0f, 0.0f, 1.0f, 0.0f,
      0.0f, 0.0f, 0.0f, 1.0f };
   glUniformMatrix4fv(mvpMat_uniform, 1, TRUE, (GLfloat*)transMat);

   // Finally, we draw
   glBindVertexArray(vertexArrayBufferObject);
   glDrawElements(GL_TRIANGLES, NUM_INDEX, GL_UNSIGNED_SHORT, 0);

   // Reset everything
   glBindVertexArray(0);
   glUseProgramObjectARB(0);
}

int main (int argc, char* argv[])
{
   // We are going to draw some triangles
   BouncingTriangle triangleModule;

   if ( SDL_Init(SDL_INIT_VIDEO) != 0 ) {
      printf("Unable to initialize SDL: %s\n", SDL_GetError());
      return 1;
   }

   SDL_GL_SetAttribute( SDL_GL_DOUBLEBUFFER, 1 );
   int w = 640, h = 480;
   SDL_Surface* screen = SDL_SetVideoMode( w, h, 0, SDL_OPENGL );

   // OpenGL is ready to go
   triangleModule.onReadyOpenGL(w, h);

   // Let the module know about the keymap, in case it wants to use that
   triangleModule.keys = SDL_GetKeyState(NULL);

   while (!triangleModule.isDone()) {
      // Handle drawing
      triangleModule.onDisplay();
      SDL_GL_SwapBuffers();

      // Handle events
      SDL_Event event;
      while ( SDL_PollEvent(&event) ) {
         triangleModule.onEvent(event);
      }
   }

   SDL_Quit();
   return 0;
}
